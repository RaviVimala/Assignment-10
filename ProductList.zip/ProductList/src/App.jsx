import React from 'react'
import HeroSection from './Components/HeroSection';
import ProductList from './Components/productList';
import ProductCard from './Components/productCard';
import Contact from './Components/contact';
import './index.css';

function App() {
  return (
    <div class="App-Container">
      
      <HeroSection/>
      <ProductList/>
      <ProductCard/>
      <Contact/>

    </div>
  );
}

export default App;
