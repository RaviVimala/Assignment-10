import React, { useState } from "react";
import ProductCard from "./productCard";


const ProductList = () => {
const productsData = [

{ id: 23, name: "Oppo F29 PRO", category:"LatestModel", price:1299 , rating: 4.4, image:"https://i.ytimg.com/vi/Lmo1D5_tAF4/maxresdefault.jpg" },
{ id: 24, name: "Oppo F29 PRO", category:"LatestModel", price:1299 , rating: 4.4, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbzw5VDW7ck8wciccw8dxzsBQ0zRrJe-CleFO8jGX5efXS2XysB5MjtOWYKAuuNGgMkyk&usqp=CAU"},

{ id: 1, name: "Samsung Guru ", category: "Basic Phones", price: 1200, rating: 4.3, image:"https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTfrx580I7nFLYDCILCF1Nb4l8q-_YMQIFWSi5oU37r4pS0UWCNMNM33oS2zPMexCV3W73BQ7B2NgbqFHWg8_1VwVBt-36DCisS42vWYyZB" },
{ id: 2, name: "Nokia 105", category: "Basic Phones", price: 1200, rating: 4.2, image:" https://m.media-amazon.com/images/I/61v3V9bh1iL.jpg" },

{ id: 3, name: "Dual Sim Nokia 130 ", category: "DualSim", price: 1800, rating: 4.5,image:"https://m.media-amazon.com/images/I/616nGg8LpsL.jpg" },
{ id: 4, name: "Dual Sim Nokia 5310", category: "DualSim", price: 4500, rating: 4.2,image:"https://rukminim2.flixcart.com/image/1200/1200/xif0q/mobile/i/n/i/5310-ds-keypad-mobile-fm-radio-camera-with-flash-8mb-ram-ta-1212-original-imah4kgvasydq93j.jpeg" },

{ id: 5, name: "Motorola g05 ", category: "SmartPhone", price: 6999, rating: 4.0 ,image:"https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRXAmYRqQHO99wkXOhfM01ILpEsz1PRufprDoIapIAKajG1uGN_IqNiFkW-hkvvOZWmBNfmwm9BhNEol4M5YePVGaBpczVVHjecbhJkUWE"},
{ id: 6, name: "Motorola g05 Plum Red", category: "SmartPhone", price: 7733, rating: 4.0 ,image:"https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRtV6_MF1PXVi-NK9vgfQ-YumrCia3hHYq0dGEQcv60j7BBQ-_xrotju6T4WO8M2O8egzPXeOyBK9vZus9CjoOHxOHmhECQgCEI-Cbfmx0"},

{ id: 7, name: "Samsung Galaxy", category: "SmartPhone", price: 6300, rating: 4.3,image:"https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcTGAmp_Exa5g-MnQBFBMPxIJ__TsOrr0D7y-_wMQdxobyiWAXTQWKjn7MwUXPwFR90i7aw30gN1mKw6V6RG9Cc6DpGg3yMFJM9OmDwJIVOL_D06MVdW0VgD" },
{ id: 8, name: "Samsung Galaxy", category: "SmartPhone", price: 9899, rating: 4.2 ,image:"https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcSY4caTeGc4VRxahJ1cD3g72nEZADZOKHQgSX3bWogxrSaKCJAWmZZTgXdgP9AhjXE8BwJMnVlpnmJcuHtVE26cuIrEeFkJtUp3KYaf_QgEE6dsL_iano9n"},

{ id: 9, name: "One Plus", category: "Android", price: 23999, rating: 4.2,image:"https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcQXVerkosotnYn4SjvLxzfOt2KFxsZIhJb34VPrDxWFPRiCbTPZST2vzIbsESMIU3Y8fh0ro4IR-smyTnt9o_b4IME0Eu6sFBGCkHaCIzE" },
{ id: 10, name: "One Plus", category: "Android", price: 13299, rating: 4.4,image:"https://s3bg.cashify.in/gpro/uploads/2022/05/25105210/oneplus-nord-ce-4-lite-5g-front-display-1.webp" },

{ id: 11, name: "Redmi A4 ", category: "Android", price: 8799, rating: 4.3 ,image:"https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTs8LBj7wWohz6-eR4x1aQx2UtjnDOS2yOlA1IT0VJLMoqdHrEVzR8EwUpLiK9JyhgewTEN8ixiLWTrRHa3p-T3B2YquRXO07yvuSUVYvaIzAU3RDkrqUW4"},
{ id: 12, name: " Redmi 12 5G ", category: "Android", price:8999, rating: 4.2 ,image:"https://assetscdn1.paytm.com/images/catalog/product/E/ED/EDCXIAOMI-SPL-RPAYT1152435B4A92A77/0.jpg"},

{ id: 13, name: "Zebronics", category: "PowerBank", price: 600, rating: 4.3 ,image:"https://m.media-amazon.com/images/I/51TwwH5J9WL.jpg"},
{ id: 14, name: "BoAt", category: "PowerBank", price: 1699, rating: 4.3,image:"https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcRtKXIQaDOZvOFzwLtR_5beVemcZ4mTOEWmrPtNHAdhfQSUBWIxbLPhcHzjPsM4nEbV17B9LW4c9H6MlM6w7k8z7CVbeATa5vT_52mkles"},

{ id: 15, name: "Intex ", category: "PowerBank ", price: 300, rating: 3.8 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFOY2aviGevt59oVpPTCanaserr0smRZM8Aw&s"},
{ id: 16, name: "Ambrane Aero ", category: "PowerBank", price: 25, rating: 4.0,image:"https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQBJmm0V4IEwImFgMQAZ8zp-c4YfM5FS437nr9oMbXNWFoeFnZeb0HGHutBxcsuR8XUFwUGh3JRp91jrBOz3BQzJNoDbTe5UhDjQFPFILmS" },

{ id: 17, name: "Zebronics Zeb", category:"Headphone", price: 499, rating: 4.5, image:"https://m.media-amazon.com/images/I/61FrvQMXxJL.jpg"},
{ id: 18, name: "boAt", category:"Headphone", price: 899, rating: 4.5, image:"https://assetscdn1.paytm.com/images/catalog/product/M/MO/MOBBOAT-OVER-EAHELL111146016E3DF16/0..jpeg"},

{ id: 19, name: "Portronics", category:"Headphone", price: 699, rating:4.4 , image:"https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQsF8GQtiZoCzsVCyrhaRD9qaFAwCPNakz9E--pEFP0IgXn3lozcZ7OGApM5e9bMadbkods5_5zQzv_Z58H8mgGeQhk8IkTeidOZ5PDcEw"},
{ id: 20, name: "JBL Tune", category:"Headphone", price:1299 , rating: 4.4, image:"https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcS5vnOPSDv6fgM6rOoPQLZ6s9K_ajgtiv9iBHZshZdf5Dcjnins-45ODxZqbtrhV59EPoyDishwTJ59YzhMYA_wrjKyW6LmqfQZsQ5BHijMAvpmOXIcbJAYBQ"},

{ id: 21, name: "Oppo", category:"LatestModel", price:1299 , rating: 4.4, image:"https://opsg-img-cdn-gl.heytapimg.com/epb/202506/23/zQEwDm0QEsgb8Uiy.png"},
{ id: 22, name: "Oppo", category:"LatestModel", price:1299 , rating: 4.4, image:"https://image.oppo.com/content/dam/oppo/common/mkt/v2-2/k13-turbo-series-in/list-page/k13-turbo-pro/448-600-silver-v1.png" },




];

const [searchTerm, setSearchTerm] = useState("");
const [category, setCategory] = useState("All");
const [sortOption, setSortOption] = useState("");
const [products] = useState(productsData);

// Filter + Search
const filteredProducts = products
.filter((product) =>
product.name.toLowerCase().includes(searchTerm.toLowerCase())
)
.filter((product) =>
category === "All" ? true : product.category === category
)
.sort((a, b) => {
if (sortOption === "price-low-high") return a.price - b.price;
if (sortOption === "price-low-high") return b.price - a.price;
if (sortOption === "rating-high-low") return b.rating - a.rating;
return 0;
});

return (
<div  className=" bg-[#faf8f7] border-1 rounded" >
{/* Filters */}
<div className="filters px-70 py-10 items-center space-x-4">
<input
type="text"
placeholder="Search products..."
value={searchTerm}
onChange={(e) => setSearchTerm(e.target.value)}
/>

<select value={category} onChange={(e) => setCategory(e.target.value)}>
<option value="All">All Categories</option>
<option value="Basic Phones">Basic Phones </option>
<option value="DualSim">DualSim</option>
<option value="SmartPhone">SmartPhones</option>
<option value="Android">Android</option>
<option value="PowerBank">PowerBank</option>
<option value="Headphone">Headphone</option>

<option value="LatestModel">LatestModel</option>
</select>

<select value={sortOption} onChange={(e) => setSortOption(e.target.value)}>
<option value="">Sort By</option>
<option value="price-low-high">Price: Low to High</option>
<option value="price-high-low">Price: High to Low</option>
<option value="rating-high-low">Rating: High to Low</option>
</select>
</div>

{/* Product Cards */}
<div className="product-list px-60">
{filteredProducts.length > 0 ? (
filteredProducts.map((product) => (
<ProductCard key={product.id} {...product} />
))
) : (
<p>No products found</p>
)}
</div>
</div>
);
};

export default ProductList;
