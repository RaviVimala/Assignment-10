import React from 'react'
import './Hero.css'

function HeroSection() {
  return (

    <section className="max-h-screen">  
        <nav className="navbar  max-w-xxl">
    <div>
        <h1 className="title">Mobile & Apps</h1>
    </div>

<ul className="flex space-x-4 gap-4 " >{/* menulist*/}
<li ><a class="nav-link active" aria-current="page" href="#">Home</a>
</li><li class="nav-item"><a class="nav-link" href="#">About</a>
</li><li class="nav-item"><a class="nav-link" href="#">Product</a>
</li><li class="nav-item"><a class="nav-link" href="#">Features</a>
</li><li class="nav-item"><a class="nav-link" href="#">Contactus</a></li></ul>
<buttom className="bg-[#3bb0a6] text-white px-5 py-3 text-lg rounded-full">LOGIN</buttom>
</nav>
{/* herosection */}
<div className="flex justify-left  py-5 bg-[url(https://bambooagile.eu/wp-content/uploads/2021/01/Mobile-apps.png)] bg-cover  ">
  <div className="container max-w-md ">
    <p className="text-lg my-8 px-10 font-large text-gray-900  ">   </p> 
 </div><div className="p-50 "> <p className="font-l text-voilet-600 font-semibold"></p><br></br>
 </div>
</div>
</section> 
    
  )
}

export default HeroSection
