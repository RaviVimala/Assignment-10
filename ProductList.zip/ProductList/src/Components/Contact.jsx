import React from 'react'

function Contact() {
  return (
    <div className=" flex justfiy-content-center items-left  border p-10">
      <h1 className="px-40 font-bold "> Contact us for Sales <a href="#">Www.MobiTechsales.com</a></h1>
      
      <div className="items-center justify-content-left ">
        <input type="text" className="items-center justify-content-left border"  placeholder="Enter your Mail" />
        <button className="px-13 mt-3 bg-[#D96955] text-white px-2 py-3 text-lg rounded-full"> Submit </button> <br /> <br />
        <textarea name="textarea" id="textpage" placeholder='Share your Commands here...' ></textarea>
        <button className="px-12 mt-3 bg-[#2DE139] text-white font-bold text-lg rounded-full">Share</button>
      </div>
    </div>
  )
}

export default Contact;
